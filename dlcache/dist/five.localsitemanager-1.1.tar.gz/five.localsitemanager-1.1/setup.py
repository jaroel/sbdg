"""Setup for five.localsitemanager package

$Id: setup.py 101137 2009-06-19 14:27:11Z optilude $
"""
from setuptools import setup, Extension

version = '1.1'

setup(name='five.localsitemanager',
      version=version,
      url='http://svn.zope.org/five.localsitemanager',
      license='ZPL 2.1',
      description='Local site manager implementation for Zope 2',
      author='Rocky Burt and Contributors',
      author_email='zope-cmf@zope.org',
      long_description=open("README.txt").read() + "\n" + 
                       open("INSTALL.txt").read() + "\n" +
                       open("CHANGES.txt").read(),
      classifiers=[
          'Environment :: Web Environment',
          'Framework :: Zope2',
          'License :: OSI Approved :: Zope Public License',
          'Operating System :: OS Independent',
          'Programming Language :: Python',
          'Topic :: Internet :: WWW/HTTP :: Site Management',
          'Topic :: Software Development :: Libraries :: Python Modules',
      ],
      keywords='zope zope2 zope3 five sitemanager',

      packages=['five', 'five.localsitemanager'],
      package_dir = {'': 'src'},
      namespace_packages=['five',],
      include_package_data = True,
      install_requires=[
        'setuptools',
        'zope.component < 3.6dev',
      ],
      zip_safe = False,
      )
