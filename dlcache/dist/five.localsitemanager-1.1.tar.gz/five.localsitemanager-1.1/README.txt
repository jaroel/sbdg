Introduction
============

Overview
--------

five.localsitemanager attempts to provide a local site manager implementation
that is as close to Zope 3's implementation as possible. Some reservations
that do not conflict with Zope 3 have been made to ease the path with CMF.

Developer Resources
-------------------

- Subversion browser:

  http://svn.zope.org/five.localsitemanager
