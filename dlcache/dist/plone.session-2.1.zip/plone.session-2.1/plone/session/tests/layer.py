from Products.PloneTestCase.layer import ZCML

PloneSession = ZCML
