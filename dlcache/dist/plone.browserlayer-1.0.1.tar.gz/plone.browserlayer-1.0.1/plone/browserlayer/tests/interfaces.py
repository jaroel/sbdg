from zope.interface import Interface

class IMyProductLayer(Interface):
    """A layer unique to this product.
    """