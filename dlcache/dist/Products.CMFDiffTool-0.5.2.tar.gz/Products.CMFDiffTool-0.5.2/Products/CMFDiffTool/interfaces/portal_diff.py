# -*- coding: utf-8 -*-
# Copyright (c) 2003 The Connexions Project, All Rights Reserved
# Written by Brent Hendricks

"""Interface for computing object differences"""

#placeholder for bridged interfaces
