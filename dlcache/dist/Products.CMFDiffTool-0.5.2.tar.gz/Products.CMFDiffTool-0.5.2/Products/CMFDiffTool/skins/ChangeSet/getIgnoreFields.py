##parameters=

ignore_list = [
    'getRawRelatedItems',
    'isDiscussable',
    'getImage',
    'getFile',
]

return ignore_list
