
// The calendar popup show/hide:

    function showDay(date) {
        $('#day' + date).css({'visibility': 'visible'});
        return true;
    }    
    function hideDay(date) {
        $('#day' + date).css({'visibility': 'hidden'});
        return true;
    }


 


