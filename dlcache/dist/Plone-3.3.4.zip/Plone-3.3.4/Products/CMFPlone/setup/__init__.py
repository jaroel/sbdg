import os

if not os.environ.get('ZOPETESTCASE'):
    import dependencies
