""" Properties tool interface.

$Id: PropertiesTool.py 21471 2008-07-08 15:29:53Z hannosch $
"""

# BBB: module will be removed in Plone 4.0
#      zope2 interfaces created on runtime:
#      - IPortalProperties
#      - ISimpleItemWithProperties
