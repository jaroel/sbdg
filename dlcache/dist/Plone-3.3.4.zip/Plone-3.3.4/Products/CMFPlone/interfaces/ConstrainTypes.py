# BBB module will be removed in Plone 4.0
#     zope 2 interfaces created at runtime:
#     - IConstrainTypes
#     - ISelectableConstrainTypes
