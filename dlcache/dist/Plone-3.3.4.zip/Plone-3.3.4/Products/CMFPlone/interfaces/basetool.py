from zope.interface import Interface

class IPloneBaseTool(Interface):
    """Marker interface for plone tools
    """

class IPloneTool(Interface):
    """Marker interface for the plone utils tool.
    """
