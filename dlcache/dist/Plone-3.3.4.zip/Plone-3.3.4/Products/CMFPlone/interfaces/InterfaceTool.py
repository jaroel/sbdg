""" InterfaceTool interface.

$Id: InterfaceTool.py 14950 2007-05-10 19:40:25Z jfroche $
"""

# BBB: module will be removed in Plone 3.0
#      zope2 interfaces created on runtime:
#      - IInterfaceTool
