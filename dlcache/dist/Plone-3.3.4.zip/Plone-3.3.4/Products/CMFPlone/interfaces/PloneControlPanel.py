"""
Plone control panel interface
"""

# BBB: module will be removed in Plone 4.0
#      zope2 interfaces created at runtime:
#      - IControlPanel
