# BBB: This will go away - there is a reverse bridge in CMFDynamicViewFTI

from Products.CMFDynamicViewFTI.interfaces import IBrowserDefault
from Products.CMFDynamicViewFTI.interfaces import ISelectableBrowserDefault
from Products.CMFDynamicViewFTI.interfaces import IDynamicViewTypeInformation
