"""\
Unit test package for PTS
"""
GLOBALS = globals()
