# Interface definitions
