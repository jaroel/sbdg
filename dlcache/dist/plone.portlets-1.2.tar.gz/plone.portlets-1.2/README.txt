plone.portlets Package Readme
=========================

Overview
--------

An extension of zope.viewlet to support dynamic portlets
