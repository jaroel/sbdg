The description of the Typewriter application will follow.
