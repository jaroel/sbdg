The description of the Snake application will follow.
