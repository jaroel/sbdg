/* We define this document variable so that base2 can be used in the tests */
var document = {};
var window = {};
