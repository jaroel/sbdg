kss.code Package Readme
=======================

Overview
--------

KSS (Kinetic Style Sheets) core framework
