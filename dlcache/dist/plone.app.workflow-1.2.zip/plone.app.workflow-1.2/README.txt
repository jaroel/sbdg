Introduction
============

plone.app.workflow contains workflow- and security-related features for Plone,
including the sharing view.

