from widget import macrowidget
from i18n import translate