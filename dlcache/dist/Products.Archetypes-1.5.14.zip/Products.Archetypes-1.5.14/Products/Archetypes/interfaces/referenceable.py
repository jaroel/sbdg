"""
Referenceable interface
"""

# BBB: module will be removed
#      zope2 interfaces created at runtime
#      - IReferenceable
