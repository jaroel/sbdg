"""
Base Archetypes interfaces.
"""

# BBB: module will be removed
#      zope2 interfaces created at runtime
#      - IBaseObject
#      - IBaseContent
#      - IBaseFolder
#      - IBaseUnit
