Plone Tableless

Plone Tableless provides a completly tableless version of
the Plone Default theme, and was created because version 3.0
does no longer ship with a tableless theme other than NuPlone.

The theme was tested on the following browsers:

* Firefox 2.0 WinXP/Mac OS X

* Camino 1.5.4 Mac OS X

* Safari 3.0.4 Mac OS X

* Opera 9.0 WinXP

* Internet Explorer 6/7 WinXP
