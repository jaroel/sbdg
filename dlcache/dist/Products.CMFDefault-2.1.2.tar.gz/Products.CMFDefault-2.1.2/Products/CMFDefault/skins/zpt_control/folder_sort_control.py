##parameters=key='position', reverse=0, **kw
##title=Sort objects in a folder
##
context.setDefaultSorting(key, reverse)

return context.setStatus(True)
