(See Products/CMFDefault/README.txt).
