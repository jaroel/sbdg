wicked Package Readme
=========================

Overview
--------

wicked is a compact syntax for doing wiki-like content linking and creation
