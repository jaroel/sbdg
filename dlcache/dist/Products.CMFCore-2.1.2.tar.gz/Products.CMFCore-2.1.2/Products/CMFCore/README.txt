==================
 Products.CMFCore
==================

.. contents::

This product declares the key framework services for the Zope
Content Management Framework (CMF).
