#
#   TestRecord      - Used for FSZSQLMethod tests
#

class MyRecord:

    def my_uncle(self):
        """ Bruce is my uncle """
        return 'bruce'

