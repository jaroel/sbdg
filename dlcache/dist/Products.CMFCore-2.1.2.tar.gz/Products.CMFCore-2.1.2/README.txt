(See Products/GenericSetup/README.txt).
