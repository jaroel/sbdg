# just to be compatible with the general AT approach

PROJECTNAME = "ATReferenceBrowserWidget"
SKINS_DIR = 'skins'
GLOBALS = globals()

from Products.CMFCore.permissions import AddPortalContent

ADD_CONTENT_PERMISSION = AddPortalContent
