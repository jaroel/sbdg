"""\
Unit test package for CMFCalendar.

As test suites are added, they should be added to the
mega-test-suite in Products.CMFCalendar.tests.test_all.py
"""
