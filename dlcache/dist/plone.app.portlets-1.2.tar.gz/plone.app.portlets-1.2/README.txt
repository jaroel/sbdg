Introduction
=============

plone.app.portlets provides a Plone-specific user interface for 
plone.portlets, as well as a standard set of portlets that ship with Plone.

