Overview
========

A collection of generally useful vocabularies for usage in zope.formlib.
