Introduction
============

plone.app.content contains various views for Plone, such as 
folder_contents, as well as general content infrastructure, such as
base classes and name choosers.

