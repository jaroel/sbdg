#
# Activate support for old kss.demo version
import bbb_oldkssdemo
