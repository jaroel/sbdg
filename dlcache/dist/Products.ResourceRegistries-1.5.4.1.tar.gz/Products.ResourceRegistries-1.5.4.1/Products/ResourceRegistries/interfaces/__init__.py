from registries import IResourceRegistry, ICSSRegistry, IKSSRegistry, IJSRegistry
from viewletmanagers import IHtmlHeadScripts, IHtmlHeadStyles
