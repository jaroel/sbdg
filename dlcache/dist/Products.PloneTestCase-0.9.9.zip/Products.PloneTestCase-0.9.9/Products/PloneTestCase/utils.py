#
# Utility functions
#

# $Id: utils.py 33992 2006-11-22 09:11:31Z shh42 $

from Testing.ZopeTestCase.utils import *

# BBB
from five import safe_load_site_wrapper

