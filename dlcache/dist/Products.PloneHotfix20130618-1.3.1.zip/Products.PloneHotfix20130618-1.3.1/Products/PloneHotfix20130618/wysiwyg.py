from Products.kupu.plone.plonelibrarytool import PloneKupuLibraryTool


if hasattr(PloneKupuLibraryTool.getWysiwygmacros.im_func, '__doc__'):
    del PloneKupuLibraryTool.getWysiwygmacros.im_func.__doc__
