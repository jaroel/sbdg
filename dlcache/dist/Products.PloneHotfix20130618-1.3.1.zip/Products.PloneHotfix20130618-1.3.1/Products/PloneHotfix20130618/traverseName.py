from ZPublisher.BaseRequest import BaseRequest


BaseRequest.traverseName__roles__ = ()