from OFS.CopySupport import CopyContainer


CopyContainer.cb_dataItems__roles__ = ()