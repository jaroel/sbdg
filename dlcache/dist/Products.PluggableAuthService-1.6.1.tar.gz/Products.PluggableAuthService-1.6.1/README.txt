(See Products/PluggableAuthService/README.txt).
