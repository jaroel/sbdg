Introduction
============

This package contains the translation files for Plone Core and the
LinguaPlone add-on product.
