tinyMCE.addI18n('tr.advhr_dlg',{
width:"Geni\u015Flik",
size:"Y\u00FCkseklik",
noshade:"G\u00F6lge yok"
});