tinyMCE.addI18n('lv.advhr_dlg',{
width:"Platums",
size:"Augstums",
noshade:"Bez \u0113nas"
});