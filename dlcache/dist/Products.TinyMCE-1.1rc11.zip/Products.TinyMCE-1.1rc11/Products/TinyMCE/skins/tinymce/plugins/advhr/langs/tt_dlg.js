tinyMCE.addI18n('tt.advhr_dlg',{
width:"\u5BEC",
size:"\u9577",
noshade:"\u7121\u9670\u5F71"
});