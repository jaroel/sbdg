tinyMCE.addI18n('te.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});