tinyMCE.addI18n('th.advhr_dlg',{
width:"\u0E01\u0E27\u0E49\u0E32\u0E07",
size:"\u0E2A\u0E39\u0E07",
noshade:"\u0E44\u0E21\u0E48\u0E21\u0E35\u0E40\u0E07\u0E32"
});