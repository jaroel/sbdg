tinyMCE.addI18n('br.paste_dlg',{
text_title:"Use CTRL+V para colar o texto na janela.",
text_linebreaks:"Manter quebras de linha",
word_title:"Use CTRL+V para colar o texto na janela."
});