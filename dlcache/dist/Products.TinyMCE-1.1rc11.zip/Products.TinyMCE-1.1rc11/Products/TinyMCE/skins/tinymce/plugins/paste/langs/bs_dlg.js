tinyMCE.addI18n('bs.paste_dlg',{
text_title:"Koristite CTRL+V na tipkovnici da zalijepite tekst u prozor.",
text_linebreaks:"Zadr\u017Ei prijelome",
word_title:"Koristite CTRL+V na tipkovnici da zalijepite tekst u prozor."
});