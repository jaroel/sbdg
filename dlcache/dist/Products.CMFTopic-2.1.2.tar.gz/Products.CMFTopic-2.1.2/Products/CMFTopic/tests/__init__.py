"""
This package contains the unit tests for Topic and its criteria objects.
"""
