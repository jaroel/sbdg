===================
 Products.CMFTopic
===================

.. contents::

This product declares a topic content type for the
Zope Content Management Framework (CMF).
