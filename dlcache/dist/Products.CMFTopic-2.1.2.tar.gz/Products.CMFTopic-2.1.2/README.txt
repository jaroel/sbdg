(See Products/CMFTopic/README.txt).
