#

def initialize(context):
    """Initializer used when loading this package as a Zope 2 product.
    """