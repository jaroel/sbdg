(See Products/CMFActionIcons/README.txt).
