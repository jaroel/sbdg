=========================
 Products.CMFActionIcons
=========================

.. contents::

Overview
========

The action icons tool provides a centralized registry mapping CMF
"actions" (identified by their category and ID) to additional presentation
metadata (display title and icon).  The skins here show alternative
mechanisms for using this metadata within a site template.
