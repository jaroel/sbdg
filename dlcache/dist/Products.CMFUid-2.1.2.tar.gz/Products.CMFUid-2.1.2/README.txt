(See Products/CMFUid/README.txt).
