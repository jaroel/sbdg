"""Quickinstaller Extensions package"""
