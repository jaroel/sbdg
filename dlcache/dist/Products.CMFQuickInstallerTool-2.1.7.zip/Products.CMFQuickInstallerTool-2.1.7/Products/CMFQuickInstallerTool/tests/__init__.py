"""QuickInstaller tests package."""
