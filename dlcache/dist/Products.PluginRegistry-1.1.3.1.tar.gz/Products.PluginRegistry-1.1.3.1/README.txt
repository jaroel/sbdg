(See Products/PluginRegistry/README.txt).
