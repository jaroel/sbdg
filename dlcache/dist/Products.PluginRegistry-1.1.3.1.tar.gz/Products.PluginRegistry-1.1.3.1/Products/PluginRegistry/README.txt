Products.PluginRegistry README

