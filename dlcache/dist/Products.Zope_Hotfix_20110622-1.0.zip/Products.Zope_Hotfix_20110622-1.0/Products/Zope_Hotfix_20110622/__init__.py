def initialize(context):
    import patch
