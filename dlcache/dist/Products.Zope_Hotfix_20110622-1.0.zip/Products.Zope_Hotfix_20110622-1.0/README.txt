Zope Hotfix 20110622
********************

This is a critical security hotfix which should be applied to the following
versions of Zope:

* Zope 2.13 <= 2.13.7 (Plone 4.1 <= 4.1rc3)
* Zope 2.12 <= 2.12.18 (Plone 4.0 <= 4.0.7)
* Any version of Zope 2.10 or Zope 2.11 where PloneHotfix20110720_ is installed
  (Plone 3.0, 3.1, 3.2 and 3.3 <= 3.3.5).

Additional information about the hotfix including frequently asked questions
is available at http://plone.org/products/plone/security/advisories/20110622

This hotfix applies the following modifications to improve Zope security:

* Disables the acquire, attribute, item, lang and vh traversers.
* Patches the traverse method of zope.traversing.namespaces.resource.

.. _PloneHotfix20110720: http://plone.org/products/plone-hotfix/releases/CVE-2011-0720

Installation
============

Installation instructions can be found at
http://plone.org/products/plone-hotfix/releases/20110622
