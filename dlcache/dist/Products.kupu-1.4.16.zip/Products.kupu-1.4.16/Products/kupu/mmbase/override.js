; Override few message from kupu, this makes them appear in mymessages.jspx, and hence work.
_("strong: alt-b")
_("emphasis: alt-i")
